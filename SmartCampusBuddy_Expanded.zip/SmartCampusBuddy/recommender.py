import sqlite3
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel

DB = 'data.db'

def _load_resources():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT id, title, description, tags, url FROM resources")
    rows = c.fetchall()
    conn.close()
    return rows

def recommend_resources(query, top_n=5):
    rows = _load_resources()
    if not rows:
        return []
    docs = []
    ids = []
    for r in rows:
        ids.append(r[0])
        docs.append(" ".join([str(r[1] or ''), str(r[2] or ''), str(r[3] or '')]))
    vectorizer = TfidfVectorizer(stop_words='english')
    tfidf = vectorizer.fit_transform(docs + [query])
    cosine_similarities = linear_kernel(tfidf[-1], tfidf[:-1]).flatten()
    top_indices = cosine_similarities.argsort()[-top_n:][::-1]
    recs = []
    for idx in top_indices:
        score = float(cosine_similarities[idx])
        r = rows[idx]
        recs.append({'id': r[0], 'title': r[1], 'description': r[2], 'tags': r[3], 'url': r[4], 'score': round(score,4)})
    return recs
