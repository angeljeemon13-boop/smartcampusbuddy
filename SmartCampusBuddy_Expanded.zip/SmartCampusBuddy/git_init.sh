#!/bin/bash
# Usage: bash git_init.sh "Your Name" "your.email@example.com"
NAME="${1:-Contributor}"
EMAIL="${2:-you@example.com}"
git init
git config user.name "$NAME"
git config user.email "$EMAIL"
git add .
git commit -m "Initial project skeleton: SmartCampusBuddy"
git branch -M main
git tag v0.1
# Example feature commits (local)
git checkout -b feature/auth
# Simulate changes (no-op), then commit
git commit --allow-empty -m "Add basic authentication (routes and templates)"
git checkout main
git merge --no-ff feature/auth -m "Merge auth feature"
git commit --allow-empty -m "Add Dockerfile and CI workflow"
echo "Git history created. Push to your remote repository with:"
echo "  git remote add origin <your-repo-url>"
echo "  git push -u origin main --tags"
