import sqlite3
import os
from recommender import recommend_resources

DB = 'data.db'

def setup_module(module):
    # create a fresh DB with known entries
    if os.path.exists(DB):
        os.remove(DB)
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("CREATE TABLE resources (id INTEGER PRIMARY KEY, title TEXT, description TEXT, tags TEXT, url TEXT)")
    c.execute("INSERT INTO resources (title,description,tags,url) VALUES (?,?,?,?)",
              ("Linear Algebra Basics","Matrices and vectors","math,linear algebra","http://example.com/la"))
    c.execute("INSERT INTO resources (title,description,tags,url) VALUES (?,?,?,?)",
              ("Advanced Python","Decorators and generators","python,advanced","http://example.com/py"))
    conn.commit()
    conn.close()

def teardown_module(module):
    if os.path.exists(DB):
        os.remove(DB)

def test_recommender_returns_results():
    recs = recommend_resources("python")
    assert isinstance(recs, list)
    assert len(recs) >= 1
    assert any("python" in (r['tags'] or '') for r in recs)
