from flask import Flask, render_template, request, redirect, url_for, session, g, flash
import sqlite3, os
from recommender import recommend_resources
from werkzeug.security import generate_password_hash, check_password_hash

DB = 'data.db'
SECRET_KEY = os.environ.get('SCB_SECRET_KEY', 'dev-secret-key')

app = Flask(__name__)
app.secret_key = SECRET_KEY

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    if not os.path.exists(DB):
        conn = get_db()
        c = conn.cursor()
        c.execute("""CREATE TABLE users (
            id INTEGER PRIMARY KEY, username TEXT UNIQUE, password_hash TEXT
        )""")
        c.execute("""CREATE TABLE resources (
            id INTEGER PRIMARY KEY, title TEXT, description TEXT, tags TEXT, url TEXT, owner_id INTEGER
        )""")
        # sample resources
        c.execute("INSERT INTO resources (title,description,tags,url,owner_id) VALUES (?,?,?,?,?)",
                  ("Intro to Python","Beginner Python tutorial","python,programming","https://docs.python.org/3/tutorial/", NULL))
        c.execute("INSERT INTO resources (title,description,tags,url,owner_id) VALUES (?,?,?,?,?)",
                  ("Flask Quickstart","Build web apps with Flask","flask,web,python","https://flask.palletsprojects.com/", NULL))
        conn.commit()
        conn.close()

@app.before_request
def load_logged_in_user():
    g.user = None
    if 'user_id' in session:
        conn = get_db()
        c = conn.cursor()
        c.execute("SELECT id, username FROM users WHERE id = ?", (session['user_id'],))
        row = c.fetchone()
        if row:
            g.user = dict(row)

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db()
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users (username, password_hash) VALUES (?,?)",
                      (username, generate_password_hash(password)))
            conn.commit()
            flash('Registered successfully. Please login.')
            return redirect(url_for('login'))
        except Exception as e:
            flash('Registration failed: ' + str(e))
    return render_template('register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db()
        c = conn.cursor()
        c.execute("SELECT id, username, password_hash FROM users WHERE username = ?", (username,))
        row = c.fetchone()
        if row and check_password_hash(row['password_hash'], password):
            session.clear()
            session['user_id'] = row['id']
            flash('Logged in successfully.')
            return redirect(url_for('index'))
        else:
            flash('Invalid credentials.')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/')
def index():
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id,title,description,tags,url FROM resources")
    rows = c.fetchall()
    return render_template('index.html', resources=rows, user=g.user)

@app.route('/add', methods=['POST'])
def add():
    if not g.user:
        flash('Please login to add resources.')
        return redirect(url_for('login'))
    title = request.form['title']
    desc = request.form['description']
    tags = request.form['tags']
    url = request.form['url']
    conn = get_db()
    c = conn.cursor()
    c.execute("INSERT INTO resources (title,description,tags,url,owner_id) VALUES (?,?,?,?,?)",
              (title,desc,tags,url,g.user['id']))
    conn.commit()
    return redirect(url_for('index'))

@app.route('/recommend', methods=['POST'])
def recommend():
    keyword = request.form['keyword']
    recommendations = recommend_resources(keyword)
    return render_template('recommend.html', keyword=keyword, recs=recommendations, user=g.user)

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
