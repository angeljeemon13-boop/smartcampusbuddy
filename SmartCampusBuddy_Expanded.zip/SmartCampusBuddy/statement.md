# statement.md

**Project Title:** SmartCampusBuddy

(See README for details.)
